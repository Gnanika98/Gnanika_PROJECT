package com.capgemini.surveyapp.exception;

import org.apache.log4j.Logger;

public class SurveyIdNotFoundException extends RuntimeException{
	String message="surveyor Id is not found";
	public org.apache.log4j.Logger logger = Logger.getLogger(InvalidSurveyorMisMatchException.class);

	public String exceptionMessage() {
		return message;
	}
}
