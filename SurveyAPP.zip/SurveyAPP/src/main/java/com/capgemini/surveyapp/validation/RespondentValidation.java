package com.capgemini.surveyapp.validation;

public interface RespondentValidation {
	public boolean answerValidation(String answer);

	public boolean singleLineQuestionValidation(String singleline);
	
	public boolean MultipleLineQuestionValidation(String multipleline);

	public boolean choiceRespValid(String responsesresponses);

	public boolean DistribValid(String s);

	public boolean UseridValidation(String userid);
}
