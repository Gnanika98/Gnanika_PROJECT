package com.capgemini.surveyapp.Bean;

public class Surveyor {
	private String surveyUserid;
	private String surveyPassword;
	private String surveyFirstName;
	private String surveyContactNumber;
	private String surveyLastName;
	public String getSurveyUserid() {
		return surveyUserid;
	}
	public void setSurveyUserid(String surveyUserid) {
		this.surveyUserid = surveyUserid;
	}
	public String getSurveyPassword() {
		return surveyPassword;
	}
	public void setSurveyPassword(String surveyPassword) {
		this.surveyPassword = surveyPassword;
	}
	public String getSurveyFirstName() {
		return surveyFirstName;
	}
	public void setSurveyFirstName(String surveyFirstName) {
		this.surveyFirstName = surveyFirstName;
	}
	public String getSurveyContactNumber() {
		return surveyContactNumber;
	}
	public void setSurveyContactNumber(String surveyContactNumber) {
		this.surveyContactNumber = surveyContactNumber;
	}
	public String getSurveyLastName() {
		return surveyLastName;
	}
	public void setSurveyLastName(String surveyLastName) {
		this.surveyLastName = surveyLastName;
	}
	@Override
	public String toString() {
		return "Surveyor [surveyUserid=" + surveyUserid + ", surveyPassword=" + surveyPassword + ", surveyFirstName="
				+ surveyFirstName + ", surveyContactNumber=" + surveyContactNumber + ", surveyLastName="
				+ surveyLastName + "]";
	}
	

}