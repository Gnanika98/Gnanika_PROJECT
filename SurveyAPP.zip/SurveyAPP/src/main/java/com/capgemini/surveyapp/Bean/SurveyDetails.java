package com.capgemini.surveyapp.Bean;

import java.time.LocalDate;
import java.util.Arrays;

public class SurveyDetails {
	private String accessor;
	private String id;
	private String Name;
	private String Descrip;
	private LocalDate startDate;
	private LocalDate endDate;
	private String Q1option1, Q1option2, Q1option3, Q1option4;
	private String Q2option1, Q2option2, Q2option3, Q2option4;
	

	public String getAccessor() {
		return accessor;
	}

	public void setAccessor(String accessor) {
		this.accessor = accessor;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getDescrip() {
		return Descrip;
	}

	public void setDescrip(String descrip) {
		Descrip = descrip;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getQ1option1() {
		return Q1option1;
	}

	public void setQ1option1(String q1option1) {
		Q1option1 = q1option1;
	}

	public String getQ1option2() {
		return Q1option2;
	}

	public void setQ1option2(String q1option2) {
		Q1option2 = q1option2;
	}

	public String getQ1option3() {
		return Q1option3;
	}

	public void setQ1option3(String q1option3) {
		Q1option3 = q1option3;
	}

	public String getQ1option4() {
		return Q1option4;
	}

	public void setQ1option4(String q1option4) {
		Q1option4 = q1option4;
	}

	public String getQ2option1() {
		return Q2option1;
	}

	public void setQ2option1(String q2option1) {
		Q2option1 = q2option1;
	}

	public String getQ2option2() {
		return Q2option2;
	}

	public void setQ2option2(String q2option2) {
		Q2option2 = q2option2;
	}

	public String getQ2option3() {
		return Q2option3;
	}

	public void setQ2option3(String q2option3) {
		Q2option3 = q2option3;
	}

	public String getQ2option4() {
		return Q2option4;
	}

	public void setQ2option4(String q2option4) {
		Q2option4 = q2option4;
	}

	private String QuestionsHasOneOption;
	private String QuestionsHasMultipleOption;
	private String QuestionsHasSingleLine;
	private String QuestionsModelDescripitive;

	public String getQuestionsHasOneOption() {
		return QuestionsHasOneOption;
	}

	public void setQuestionsHasOneOption(String questionsHasOneOption) {
		QuestionsHasOneOption = questionsHasOneOption;
	}

	public String getQuestionsHasMultipleOption() {
		return QuestionsHasMultipleOption;
	}

	public void setQuestionsHasMultipleOption(String questionsHasMultipleOption) {
		QuestionsHasMultipleOption = questionsHasMultipleOption;
	}

	public String getQuestionsHasSingleLine() {
		return QuestionsHasSingleLine;
	}

	public void setQuestionsHasSingleLine(String questionsHasSingleLine) {
		QuestionsHasSingleLine = questionsHasSingleLine;
	}

	public String getQuestionsModelDescripitive() {
		return QuestionsModelDescripitive;
	}

	public void setQuestionsModelDescripitive(String questionsModelDescripitive) {
		QuestionsModelDescripitive = questionsModelDescripitive;
	}

	@Override
	public String toString() {
		return "CreateSurveyDetailsBean [id=" + id + ", Name=" + Name +", Descrip=" + Descrip + ", startDate="
				+ startDate + ", endDate=" + endDate +"] "+"\n"+ "\n 1." + QuestionsHasOneOption
				+ "\n a." + Q1option1 + "\n b." + Q1option2 + "\n c." + Q1option3 + "\n d."
				+ Q1option4 +"\n " +"\n 2." + QuestionsHasMultipleOption + "\n a." + Q2option1
				+ "\n b." + Q2option2 + "\n c." + Q2option3 + "\n d."+ Q2option4 +"\n "+ "\n "+"\n 3."
				+ QuestionsHasSingleLine +" \n" + " \n"+"\n 4." + QuestionsModelDescripitive + "\n";
	}


}
