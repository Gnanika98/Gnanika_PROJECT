package com.capgemini.surveyapp.service;

import com.capgemini.surveyapp.Bean.Admin;
import com.capgemini.surveyapp.dao.AdminDAO;

public interface AdminServiceLayer {

	public boolean AdminLogin(Admin adminInfoBean);

	public boolean adminService();

	public void defaultadminLogin();
 
}
