package com.capgemini.surveyapp.factory;

import com.capgemini.surveyapp.Bean.Admin;
import com.capgemini.surveyapp.Bean.Respondent;
import com.capgemini.surveyapp.Bean.RespondentDetails;
import com.capgemini.surveyapp.Bean.SurveyDetails;
import com.capgemini.surveyapp.Bean.Surveyor;
import com.capgemini.surveyapp.dao.AdminDAO;
import com.capgemini.surveyapp.dao.AdminDAOImplement;
import com.capgemini.surveyapp.dao.RespondentDAO;
import com.capgemini.surveyapp.dao.RespondentDAOImplement;
import com.capgemini.surveyapp.dao.SurveyorDAO;
import com.capgemini.surveyapp.dao.SurveyorDAOImplement;
import com.capgemini.surveyapp.service.AdminServiceLayer;
import com.capgemini.surveyapp.service.AdminServiceLayerImplement;
import com.capgemini.surveyapp.service.RespondentService;
import com.capgemini.surveyapp.service.RespondentServiceImplement;
import com.capgemini.surveyapp.service.SurveyorService;
import com.capgemini.surveyapp.service.SurveyorServiceImplement;
import com.capgemini.surveyapp.validation.InputValidation;
import com.capgemini.surveyapp.validation.InputValidationImplement;
import com.capgemini.surveyapp.validation.RespondentValidationImplement;
import com.capgemini.surveyapp.validation.SurveyorImplementValidation;

public class Factory {
	private Factory() {

	}

	public static InputValidation getInputValidationInstance() {
		return new InputValidationImplement();
	}

	public static SurveyorDAO getSurveyorDAOInstance() {
		SurveyorDAO surveyorDAO = new SurveyorDAOImplement();
		return surveyorDAO;
	}

	public static RespondentDAO getRespondentDAOInstance() {
		RespondentDAO respondentDAO = new RespondentDAOImplement();
		return respondentDAO;
	}

	public static SurveyorService getSurveyorServiceInstance() {
		SurveyorService surveyorService = new SurveyorServiceImplement();
		return surveyorService;
	}

	public static Surveyor getSurveyorBeanInstance() {
		Surveyor surveyorinfobean = new Surveyor();
		return surveyorinfobean;
	}

	public static SurveyDetails getcreateSurveyInstance() {
		SurveyDetails createsurveybean = new SurveyDetails();
		return createsurveybean;
	}

	public static SurveyorImplementValidation getSurveyorValidationInstance() {
		return new SurveyorImplementValidation();
	}

	public static SurveyDetails getCreateSurveyorBean() {
		return new SurveyDetails();
	}

	public static AdminServiceLayer getAdminServicePartInstance() {
		AdminServiceLayer admindao = new AdminServiceLayerImplement();
		return admindao;
	}

	public static Admin getAdminBeanInstance() {
		Admin admininfobean = new Admin();
		return admininfobean;
	}

	public static RespondentService getRespondentServiceInstance() {
		RespondentService respondentservice = new RespondentServiceImplement();
		return respondentservice;
	}

	public static Respondent getRespondentBeanInstance() {
		Respondent respondentinfobean = new Respondent();
		return respondentinfobean;

	}

	public static RespondentValidationImplement getRespondentValidationService() {
		return new RespondentValidationImplement();
	}

	public static RespondentDetails getRespondentDetailsBean() {
		return new RespondentDetails();
	}

}