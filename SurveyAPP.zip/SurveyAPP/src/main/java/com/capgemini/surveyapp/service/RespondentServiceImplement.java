package com.capgemini.surveyapp.service;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.SurveyAPP.bean.CreateSurveyDetailsBean;
import com.capgemini.SurveyAPP.bean.RespondentInfoBean;
import com.capgemini.surveyapp.dao.AdminDAO;
import com.capgemini.surveyapp.dao.AdminDAOImplement;
import com.capgemini.surveyapp.dao.RespondentDAO;
import com.capgemini.surveyapp.dao.RespondentDAOImplement;
import com.capgemini.surveyapp.factory.Factory;

public class RespondentServiceImplement implements RespondentService {
	static final Logger log = Logger.getLogger(RespondentServiceImplement.class);
	Scanner sc = new Scanner(System.in);

	@Override
	public void defaultrespondentLogin() {
		RespondentDAO respondentDAO1= new RespondentDAOImplement();
		respondentDAO1.RespondentLogin();
	}

	@Override
	public void respondentCreateDetails() {
		RespondentDAO respondentDAO1= new RespondentDAOImplement();
		respondentDAO1.RespondentProcessing();
	}

	@Override
	public  void getrespondentServiceLayer() {
		RespondentDAO respondentDAO1= new RespondentDAOImplement();
		respondentDAO1.respondServiceLayer();

	}

	@Override
	public void getrespondentViewResponses() {
		RespondentDAO respondentDAO1= new RespondentDAOImplement();
		respondentDAO1.respondView();
		
	}

	@Override
	public void respondentServresgistration() {
		RespondentDAO respondentDAO1= new RespondentDAOImplement();
		respondentDAO1.respondResgistration();
		
		
	}

	@Override
	public void defaultrespondent() {
		RespondentDAO respondentDAO1= new RespondentDAOImplement();
		respondentDAO1.defaultRespondentLogin();
		
		
	}

	/*@Override
	public void getNoOFDistriubtion() {
		RespondentDAO respondentDAO1= new RespondentDAOImplement();
		respondentDAO1.ReviewSurveyPendingNoOfDistri();
		
	}*/
	

}
