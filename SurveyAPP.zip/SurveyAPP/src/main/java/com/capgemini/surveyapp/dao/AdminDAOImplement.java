package com.capgemini.surveyapp.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.surveyapp.Bean.Admin;
import com.capgemini.surveyapp.Bean.Surveyor;
import com.capgemini.surveyapp.exception.InvalidSurveyorMisMatchException;
import com.capgemini.surveyapp.factory.Factory;
import com.capgemini.surveyapp.service.AdminServiceLayer;
import com.capgemini.surveyapp.service.RespondentService;
import com.capgemini.surveyapp.service.SurveyorService;
import com.capgemini.surveyapp.validation.InputValidation;
import com.capgemini.surveyapp.validation.RespondentValidation;

public class AdminDAOImplement implements AdminDAO {
	static final Logger log = Logger.getLogger(AdminDAOImplement.class);

	int count = 0;
	InputValidation inputValid = null;
	static List<Admin> admin = new ArrayList<Admin>();
	Scanner sc = new Scanner(System.in);
	
	public void defaultAdminLogin() {
		Admin adminBean = Factory.getAdminBeanInstance();
		adminBean.setAdminusername("admin");
		adminBean.setAdminpassword("12345");

		admin.add(adminBean);
	}
	
	public boolean AdminLogin(Admin adminInfoBean1) {
		InputValidation inputValid = Factory.getInputValidationInstance();
		for (Admin AdminBeans : admin) {
			log.info("enter your Userid ....[it contains [a-zA-Z1-9@$]format only]");
			String userid = sc.nextLine();
			while (!inputValid.UseridValidation(userid)) {
				System.out.println("please enter valid Userid");
				userid = sc.nextLine();
			}
			log.info("please enter Password.......[it contains [a-zA-Z1-9@$]format only]");
			String password = sc.nextLine();
			while (!inputValid.passwordValidation(password)) {
				System.out.println("please enter valid password");
				password = sc.nextLine();
			}
			try {
				if (userid.equals(AdminBeans.getAdminusername()) && password.equals(AdminBeans.getAdminpassword())) {
					log.info("Admin Userid and Password Verifed Successfully");
					log.info(" Welcome to our portal!!!!!!");
					AdminServiceLayer adminservice = Factory.getAdminServicePartInstance();
					adminservice.adminService();
					
					
				} else {
					throw new InvalidSurveyorMisMatchException();
				}
			} catch (InvalidSurveyorMisMatchException e) {
				log.error(e.exceptionMessage());

			}
		}
		return false;
	}

	@Override
	public boolean LogIntoRespAccount() {
		InputValidation inputValid = Factory.getInputValidationInstance();
		P: do {

			log.info(" Press the enter required following options ");
			log.info("1.Surveyor Portal");
		    log.info("2.Respondent Portal");
		    log.info("3.Add Surveyor");
		    log.info("4.Add Respondent" );
		    log.info("5.Exit");
			String extractPerson = sc.nextLine();
			while (!inputValid.ChoiceCheckValidate(extractPerson)) {
				log.info("please enter the valid Option");
				extractPerson = sc.nextLine();
			}
			int adminservice = Integer.parseInt(extractPerson);
			switch (adminservice) {
			case 1:
				log.info("..........Login into Surveyor Portal........");
				SurveyorService surveyorservice1 = Factory.getSurveyorServiceInstance();
				surveyorservice1.surveyorServLogin(new Surveyor());
				break;
			case 2:
				log.info("......Login into Respondent Portal.....");
				RespondentService respValid = Factory.getRespondentServiceInstance();
				respValid.defaultrespondentLogin();
				break;
			case 3:
				log.info(".........Add Surveyor.........");
				SurveyorService surveyorservice2 = Factory.getSurveyorServiceInstance();
				surveyorservice2.surveyorServRegistration();
				break ;
			case 4:
				log.info("...........Add Respondent........");
				RespondentService respValid1 = Factory.getRespondentServiceInstance();
				respValid1.respondentServresgistration();
				break;
			case 5:
				break P;
			}
		} while (true);
		return false;
}
}
