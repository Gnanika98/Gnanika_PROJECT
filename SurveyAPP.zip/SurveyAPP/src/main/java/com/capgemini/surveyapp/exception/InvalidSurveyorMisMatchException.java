package com.capgemini.surveyapp.exception;

import org.apache.log4j.Logger;

import com.capgemini.surveyapp.exception.InvalidSurveyorMisMatchException;

public class InvalidSurveyorMisMatchException  extends RuntimeException{
	String message="Login failed......";
	public org.apache.log4j.Logger logger = Logger.getLogger(InvalidSurveyorMisMatchException.class);

	public String exceptionMessage() {
		return message;
	}
}
