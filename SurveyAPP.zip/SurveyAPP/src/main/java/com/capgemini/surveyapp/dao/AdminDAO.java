package com.capgemini.surveyapp.dao;

import com.capgemini.surveyapp.Bean.Admin;

public interface AdminDAO {

	boolean AdminLogin(Admin adminInfoBean11);

	 boolean LogIntoRespAccount();

	void defaultAdminLogin();

}
