package com.capgemini.surveyapp.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.CyclicBarrier;

import org.apache.log4j.Logger;

import com.capgemini.surveyapp.Bean.Respondent;
import com.capgemini.surveyapp.Bean.RespondentDetails;
import com.capgemini.surveyapp.Bean.SurveyDetails;
import com.capgemini.surveyapp.exception.InvalidNotAuthenticateException;
import com.capgemini.surveyapp.exception.InvalidSurveyorMisMatchException;
import com.capgemini.surveyapp.exception.SurveyIdNotFoundException;
import com.capgemini.surveyapp.factory.Factory;
import com.capgemini.surveyapp.service.AdminServiceLayer;
import com.capgemini.surveyapp.service.RespondentService;
import com.capgemini.surveyapp.service.SurveyorService;
import com.capgemini.surveyapp.validation.InputValidation;
import com.capgemini.surveyapp.validation.RespondentValidation;
import com.capgemini.surveyapp.validation.SurveyorValidation;

public class RespondentDAOImplement implements RespondentDAO {
	static final Logger log = Logger.getLogger(RespondentDAOImplement.class);

	int count = 0;
	InputValidation inputValid = null;
	static List<Respondent> respondent = new ArrayList<Respondent>();
	static List<RespondentDetails> respondent1 = new ArrayList<RespondentDetails>();
	Scanner sc = new Scanner(System.in);

	public void defaultRespondentLogin() {
		Respondent respondentBean = Factory.getRespondentBeanInstance();
		List<RespondentDetails> respondentlist = new ArrayList<RespondentDetails>();
		respondentBean.setRespondentId("respondent");
		respondentBean.setRespondentPassword("123");
		respondent.add(respondentBean);
		RespondentDetails cb = Factory.getRespondentDetailsBean();
		cb.setQ1Answer1("ooty");
		String a[] = { "peak", "garden" };
		cb.setQid("1");
		cb.setAl1(a);
		cb.setQ1Answer3("Awesome Environment");
		cb.setQ1Answer4("Wonderful place for enjoyment");

		respondentlist.add(cb);

		RespondentDetails cb1 = Factory.getRespondentDetailsBean();
		cb1.setQ1Answer1("good");
		String a1[] = { "ventilator", "cholestoral checker" };
		cb1.setQid("2");
		cb1.setAl1(a1);
		cb1.setQ1Answer3("4.5");
		cb1.setQ1Answer4("EVerything working fine...");
		respondentlist.add(cb1);
		respondent1.addAll(respondentlist);

	}

	@Override
	public boolean RespondentLogin() {
		InputValidation inputValid = Factory.getInputValidationInstance();
		for (Respondent respondentbean : respondent) {
			log.info("enter your Userid ....[it contains [a-zA-Z1-9@$]format only]");
			String userid = sc.nextLine();
			while (!inputValid.UseridValidation(userid)) {
				System.out.println("please enter valid Userid");
				userid = sc.nextLine();
			}
			log.info("please enter Password.......[it contains [a-zA-Z1-9@$]format only]");
			String password = sc.nextLine();
			while (!inputValid.passwordValidation(password)) {
				System.out.println("please enter valid password");
				password = sc.nextLine();
			}
			try {
				if (userid.equals(respondentbean.getRespondentId())
						&& password.equals(respondentbean.getRespondentPassword())) {
					log.info("login Successfull");
					log.info(" Welcome to Respondent portal!!!!!!");

					log.info(" ");
					try {
						for (SurveyDetails respbean : SurveyorDAOImplement.surveyor1) {
							if (respbean.getAccessor().contentEquals(userid)) {
								RespondentService respondentservice = Factory.getRespondentServiceInstance();
								respondentservice.respondentCreateDetails();
							} else
								throw new InvalidNotAuthenticateException();
						}
					} catch (InvalidNotAuthenticateException e1) {
						log.info(e1.exceptionMessage());
					} catch (NullPointerException e) {
						e.getMessage();
					}
				} else {
					throw new InvalidSurveyorMisMatchException();
				}
			} catch (InvalidSurveyorMisMatchException e) {
				log.error(e.exceptionMessage());

			}
		}
		return false;
	}

	@Override
	public boolean RespondentProcessing() {
		RespondentValidation respValid = Factory.getRespondentValidationService();
		RespondentDetails cb = Factory.getRespondentDetailsBean();
		Q: do {
			log.info("please select your choice...");
			log.info("1.Give responses for survey Questionariess...");
			log.info("2.View all Responses from responders..");
			log.info("3.exit");

			String responses = sc.next();
			while (!respValid.choiceRespValid(responses)) {
				responses = sc.next();
			}
			int responses1 = Integer.parseInt(responses);

			switch (responses1) {
			case 1:
				RespondentService respondservice = Factory.getRespondentServiceInstance();
				respondservice.getrespondentServiceLayer();
				break;
			case 2:
				RespondentService respondservice1 = Factory.getRespondentServiceInstance();
				respondservice1.getrespondentViewResponses();
				break;
			case 3:
				break Q;

			}
		} while (true);
		return true;
	}

	public List<RespondentDetails> respondServiceLayer() {
		RespondentValidation respValid = Factory.getRespondentValidationService();
		RespondentDetails cb = Factory.getRespondentDetailsBean();
		Respondent rb = Factory.getRespondentBeanInstance();

		try {
			for (SurveyDetails respbean : SurveyorDAOImplement.surveyor1) {
				log.info("Please enter the surveyid for making the responses ");
				String userid = sc.nextLine();
				while (!respValid.UseridValidation(userid)) {
					log.info("please enter valid Userid for giving Responses");
					userid = sc.nextLine();
				}
				if (respbean.getId().contentEquals(userid)) {
					count++;
					log.info("the question is...");
					log.info(" ");
					log.info("1." + respbean.getQuestionsHasOneOption());
					log.info("  ");
					log.info("1." + respbean.getQ1option1());
					log.info("2." + respbean.getQ1option2());
					log.info("2." + respbean.getQ1option3());
					log.info("4." + respbean.getQ1option4());
					log.info(" ");
					log.info("please choose Single Option");
					String ans = sc.next();
					while (!respValid.answerValidation(ans)) {
						log.info("please enter the Valid Option");
						ans = sc.next();
					}
					if (ans == "1")
						cb.setQ1Answer1(respbean.getQ1option1());
					else if (ans == "2")
						cb.setQ1Answer1(respbean.getQ1option2());
					else if (ans == "3")
						cb.setQ1Answer1(respbean.getQ1option3());
					else
						cb.setQ1Answer1(respbean.getQ1option4());

					log.info(" ");

					log.info("2." + respbean.getQuestionsHasMultipleOption());
					log.info("  ");
					log.info("1." + respbean.getQ2option1());
					log.info("2." + respbean.getQ2option2());
					log.info("3." + respbean.getQ2option3());
					log.info("4." + respbean.getQ2option4());
					log.info(" ");
					HashSet<String> al = new HashSet<String>();
					log.info("how many option you will choose...");
					int a = sc.nextInt();
					for (int i = 1; i <= a; i++) {
						log.info("please choose your choice ");
						String ans1 = sc.next();
						while (!respValid.answerValidation(ans1)) {
							log.info("please enter the Valid Option");
							ans1 = sc.next();
						}
						int answer = Integer.parseInt(ans1);
						switch (answer) {
						case 1:
							log.info("1." + respbean.getQ2option1());
							al.add(respbean.getQ2option1());
							break;
						case 2:
							log.info("2." + respbean.getQ2option2());
							al.add(respbean.getQ2option2());
							break;
						case 3:
							log.info("3." + respbean.getQ2option3());
							al.add(respbean.getQ2option3());
							break;
						case 4:
							log.info("4." + respbean.getQ2option4());
							al.add(respbean.getQ2option4());
							break;
						}
					}
					String[] arr = new String[al.size()];
					int i = 0;
					for (String s : al) {
						arr[i++] = s;
					}
					cb.setAl1(arr);

					log.info(" ");
					log.info("3." + respbean.getQuestionsHasSingleLine());
					log.info("write the answer in 200 words");
					String singleline = sc.next();
					cb.setQ1Answer3(singleline);

					log.info(" ");
					log.info("4." + respbean.getQuestionsHasMultipleOption());
					log.info("write the answer in  400 words");
					String multipleline = sc.next();
					cb.setQ1Answer4(multipleline);

					cb.setRespndentid(rb.getRespondentId());
					cb.setQid(userid);
					ArrayList<RespondentDetails> sl = new ArrayList<RespondentDetails>();
					sl.add(cb);
					respondent1.addAll(sl);
					if (sl.isEmpty()) {
						log.info("Feedback is not given properly");
					} else {
						log.info("thank u for ur feedback");
					}
				}

			}
			if (count == 0)
				throw new SurveyIdNotFoundException();

		} catch (SurveyIdNotFoundException e) {
			log.info(e.exceptionMessage());
		}
		return respondent1;
	}

	@Override
	public List<RespondentDetails> respondView() {
		SurveyorValidation respValid = Factory.getSurveyorValidationInstance();
		try {
			for (RespondentDetails cb1 : respondent1) {
				for (SurveyDetails respbean : SurveyorDAOImplement.surveyor1) {
					String id = sc.nextLine();
					while (!respValid.IdValidation(id)) {
						log.info("please enter surveyid to view");
						id = sc.nextLine();
					}
					if (respbean.getId().contentEquals(id) && cb1.getQNo().contentEquals(id)) {
						count++;
						log.info(respbean.getQuestionsHasOneOption());
						log.info(respbean.getQ1option1());
						log.info(respbean.getQ1option2());
						log.info(respbean.getQ1option3());
						log.info(respbean.getQ1option4());
						log.info("Answer:" + cb1.getQ1Answer1());
						log.info(" ");
						log.info("2." + respbean.getQuestionsHasMultipleOption());
						log.info(respbean.getQ2option1());
						log.info(respbean.getQ2option2());
						log.info(respbean.getQ2option3());
						log.info(respbean.getQ2option4());
						log.info("Answer:" + Arrays.toString(cb1.getAl1()));
						log.info(" ");
						log.info("3." + respbean.getQuestionsHasSingleLine());
						log.info(cb1.getQ1Answer3());
						log.info(" ");
						log.info("4." + respbean.getQuestionsModelDescripitive());
						log.info(cb1.getQ1Answer4());
						log.info("  ");
						log.info("*************************************************************");
					}
				}
			}
			if (count == 0)
				throw new SurveyIdNotFoundException();
		} catch (SurveyIdNotFoundException e) {
			log.info(e.exceptionMessage());
		}
		return respondent1;
	}

	@Override
	public boolean respondResgistration() {
		SurveyorValidation inputValid = Factory.getSurveyorValidationInstance();
		Respondent respondentBean = Factory.getRespondentBeanInstance();

		log.info("Enter the Respondent id { It accept [1-3] characters only }");
		String id = sc.nextLine();
		while (!inputValid.IdValidation(id)) {
			log.info("enter valid id");
			id = sc.next();
		}

		log.info("Enter your First Name { It accept [a-z,A-Z] characters only }");
		String Fname = sc.next();
		while (!inputValid.NameValidation(Fname)) {
			log.info("enter valid First name");
			Fname = sc.next();
		}

		log.info("Enter your last Name { It accept [a-zA-Z] characters only }");
		String Lname = sc.next();
		while (!inputValid.NameValidation(Lname)) {
			log.info("enter valid  Last name");
			Lname = sc.next();
		}
		log.info("Enter your password...{[a-zA-Z0-9$@] format only}");
		String password = sc.next();
		while (!inputValid.passwordValidation(password)) {
			log.info("enter valid Password");
			password = sc.next();
		}

		log.info("Enter your contactNumber...{[[7-9][0-9][9] format only}");
		String contactNo = sc.next();
		while (!inputValid.contactNoValidation(contactNo)) {
			log.info("enter valid contactNumber");
			contactNo = sc.next();
		}
		respondentBean.setRespondentId(id);
		respondentBean.setRespondentFname(Fname);
		respondentBean.setRespondentLname(Lname);
		respondentBean.setRespondentContact(contactNo);
		respondentBean.setRespondentPassword(password);

		ArrayList<Respondent> RegList = new ArrayList<Respondent>();
		RegList.add(respondentBean);
		respondent.addAll(RegList);
		if (RegList.isEmpty()) {
			log.info("Respondent details is not added");
			return false;
		} else {
			log.info("Respondent details  is added Successfuly \n");
			return true;

		}

	}

}
