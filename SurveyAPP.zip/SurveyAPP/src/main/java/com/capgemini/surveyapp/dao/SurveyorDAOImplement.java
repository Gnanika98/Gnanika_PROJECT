package com.capgemini.surveyapp.dao;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.surveyapp.Bean.SurveyDetails;
import com.capgemini.surveyapp.Bean.Surveyor;
import com.capgemini.surveyapp.exception.InvalidSurveyorMisMatchException;
import com.capgemini.surveyapp.exception.SurveyIdNotFoundException;
import com.capgemini.surveyapp.factory.Factory;
import com.capgemini.surveyapp.service.RespondentService;
import com.capgemini.surveyapp.service.SurveyorService;
import com.capgemini.surveyapp.validation.InputValidation;
import com.capgemini.surveyapp.validation.InputValidationImplement;
import com.capgemini.surveyapp.validation.SurveyorImplementValidation;
import com.capgemini.surveyapp.validation.SurveyorValidation;

public class SurveyorDAOImplement implements SurveyorDAO {

	static final Logger log = Logger.getLogger(SurveyorDAOImplement.class);

	int count = 0;
	InputValidation inputValid = null;
	static List<Surveyor> surveyor = new ArrayList<Surveyor>();
	static List<SurveyDetails> surveyor1 = new ArrayList<SurveyDetails>();
	Scanner sc = new Scanner(System.in);

	public void defaultSurveyorLogin() {

		Surveyor surveyorBean = Factory.getSurveyorBeanInstance();
		surveyorBean.setSurveyUserid("surveyor");
		surveyorBean.setSurveyPassword("12345678");

		surveyor.add(surveyorBean);
	}

	public void defaultSurveyorSurveyDesc() {
		ArrayList<SurveyDetails> surveylist = new ArrayList<SurveyDetails>();

		SurveyDetails createsurveyBean = Factory.getCreateSurveyorBean();
		createsurveyBean.setAccessor("respondent");
		createsurveyBean.setId("1");
		createsurveyBean.setDescrip("This is favorite place in india..How its actually ..? ");
		createsurveyBean.setName("Favorite Place");
		createsurveyBean.setStartDate(LocalDate.of(1997, 03, 06));
		createsurveyBean.setEndDate(LocalDate.of(1998, 03, 06));
		createsurveyBean.setQuestionsHasOneOption("what is your favorite Place...?");
		createsurveyBean.setQuestionsHasMultipleOption("what are the things you like the  place....?");
		createsurveyBean.setQuestionsHasSingleLine("what is the most special in that place in single line");
		createsurveyBean.setQuestionsModelDescripitive("tell me about the place in descriptive format");
		createsurveyBean.setQ1option1("OOty");
		createsurveyBean.setQ1option2("Mysoru");
		createsurveyBean.setQ1option3("Agra ");
		createsurveyBean.setQ1option4("Goa");
		createsurveyBean.setQ2option1("Gardens");
		createsurveyBean.setQ2option2("Peak");
		createsurveyBean.setQ2option3("Museum");
		createsurveyBean.setQ2option4("lakes");

		surveylist.add(createsurveyBean);

		SurveyDetails createsurveyBean1 = Factory.getCreateSurveyorBean();
		createsurveyBean1.setId("2");
		createsurveyBean1
				.setDescrip("This is medical eqipments survey..We have to collect feedback from our customer side ");
		createsurveyBean1.setName("Medical equipment survey");
		createsurveyBean1.setStartDate(LocalDate.of(1997, 03, 06));
		createsurveyBean1.setEndDate(LocalDate.of(1998, 03, 06));
		createsurveyBean1.setQuestionsHasOneOption("How about your satisfication....?");
		createsurveyBean1.setQuestionsHasMultipleOption("which is the best Products in our company...");
		createsurveyBean1.setQuestionsHasSingleLine("Give Rate for our products...");
		createsurveyBean1.setQuestionsModelDescripitive("tell me about Products in descriptive format");
		createsurveyBean1.setQ1option1("Good");
		createsurveyBean1.setQ1option2("Bad");
		createsurveyBean1.setQ1option3("Average");
		createsurveyBean1.setQ1option4("Super");
		createsurveyBean1.setQ2option1("Sugar test Machine.");
		createsurveyBean1.setQ2option2("Ventilator...");
		createsurveyBean1.setQ2option3("cholesterol Analyser");
		createsurveyBean1.setQ2option4("Nasal tubings");
		surveylist.add(createsurveyBean1);
		surveyor1.addAll(surveylist);

	}

	@Override
	public boolean surveyorLogin(Surveyor surveyor1) {
		InputValidation inputValid = Factory.getInputValidationInstance();
		for (Surveyor surveyorBeans : surveyor) {
			log.info("enter Userid .....");
			String userid = sc.nextLine();
			while (!inputValid.UseridValidation(userid)) {
				System.out.println("please enter valid Userid");
				userid = sc.nextLine();
			}
			log.info(" Enter Password.......");
			String password = sc.nextLine();
			while (!inputValid.passwordValidation(password)) {
				System.out.println("please enter valid password");
				password = sc.nextLine();
			}
			try {
				if (userid.equals(surveyorBeans.getsUserid()) && password.equals(surveyorBeans.getsPassword())) {
					log.info(" Verifed Successfully");
					log.info("Access Granted! Welcome!");
					SurveyorService surveyorservice1 = Factory.getSurveyorServiceInstance();
					surveyorservice1.surveyorCreateSurvey();
				} else {
					throw new InvalidSurveyorMisMatchException();
				}
			} catch (InvalidSurveyorMisMatchException e) {
				log.error(e.exceptionMessage());

			}
		}
		return false;

	}

	@Override
	public boolean surveyorCreateSurveyDetails() {
		InputValidation inputValid = Factory.getInputValidationInstance();
		P: do {

			log.info(" Press the enter required following options ");
			log.info("1.Add Survey");
			log.info("2.Update Survey");
			log.info("3.Delete Survey");
			log.info("4.View Survey");
			log.info("5.ViewAll Survey");
			log.info("6.exit");
			String extractPerson1 = sc.nextLine();
			while (!inputValid.ChoiceCheckValidate(extractPerson1)) {
				log.info("please enter the valid Surveyer Option");
				extractPerson1 = sc.nextLine();
			}
			int surveyorCRUD = Integer.parseInt(extractPerson1);
			switch (surveyorCRUD) {
			case 1:
				log.info("..........Addd survey Details........");
				SurveyorService surveyorservice1 = Factory.getSurveyorServiceInstance();
				surveyorservice1.surveyorServCreate();
				break;
			case 2:
				log.info("......Update the Survey Detailsss.....");
				SurveyorService surveyorservice2 = Factory.getSurveyorServiceInstance();
				surveyorservice2.surveyorServSurveyUpdate();
				break;
			case 3:
				log.info("......Delete the Survey Details........");
				SurveyorService surveyorservice3 = Factory.getSurveyorServiceInstance();
				surveyorservice3.surveyorServSurveydelete();
				break;
			case 4:
				log.info("......View Survey Details.....");
				SurveyorService surveyorservice4 = Factory.getSurveyorServiceInstance();
				surveyorservice4.surveyorServSurveyView();
				break;
			case 5:
				log.info("......ViewAll  Survey Details.....");
				SurveyorService surveyorservice5 = Factory.getSurveyorServiceInstance();
				surveyorservice5.surveyorServSurveyViewAll();
				break;
			/*case :
				log.info("..........Review Of Pending and No of Distribution Details.......");
				RespondentService respondentBean = FactoryLayer.getRespondentServiceInstance();
				respondentBean.getNoOFDistriubtion();
				break P;*/
			case 6:
				log.info("Exit");
				break P;
			}
		} while (true);
		return false;

	}

	@Override
	public boolean surveyorCreateSurvey() {
		SurveyorImplementValidation inputValid = Factory.getSurveyorValidationInstance();
		SurveyDetails createsurveybean = Factory.getcreateSurveyInstance();

		log.info("Create your survey information here........ ");

		log.info("1.enter the id");
		String surveyid = sc.next();
		while (!inputValid.IdValidation(surveyid)) {
			log.info("enter valid Surveyid");
			surveyid = sc.next();
		}
		Integer surveyid1 = Integer.parseInt(surveyid);
		log.info("2. Name");
		String surveyName = sc.next();
		while (!inputValid.NameValidation(surveyName)) {
			log.info("enter valid Surveyid");
			surveyName = sc.next();
		}
		log.info("3. Description");
		String surveyDescription = sc.next();
		log.info("4. Start Date...[it contains YYYY-MM-DD format ]");
		String surveyStartDate = sc.nextLine();
		while (!inputValid.startDateValidation(surveyStartDate)) {
			log.info("enter valid start date....[it contains YYYY-MM-DD format ]");
			surveyStartDate = sc.nextLine();
		}
		LocalDate sd = LocalDate.parse(surveyStartDate);
		log.info("5. End Date");
		String surveyEndDate = sc.next();
		while (!inputValid.EndDateValidation(surveyEndDate)) {
			log.info("enter valid End date");
			surveyEndDate = sc.nextLine();
		}

		log.info("  ");
		log.info("Please make the question for this survey");
		log.info(" ");
		log.info("please enter the Question Has Single Option");
		String question1option = sc.next();
		log.info("enter the 1st option");
		String Q1option1 = sc.next();
		log.info("enter the 2nd option");
		String Q1option2 = sc.next();
		log.info("enter the 3rd option");
		String Q1option3 = sc.next();
		log.info("enter the 4rd option");
		String Q1option4 = sc.next();
		log.info("please enter the QuestionHasMultiple Option");
		String QuestionHasMoption = sc.next();
		log.info("enter the 1st option");
		String Q2option1 = sc.next();
		log.info("enter the 2nd option");
		String Q2option2 = sc.next();
		log.info("enter the 3rd option");
		String Q2option3 = sc.next();
		log.info("enter the 4rd option");
		String Q2option4 = sc.next();
		log.info("please enter the QuestionHas Single Line ");
		String QUestionHasSLine = sc.next();

		log.info("please enter the QuestionHasMultiple Line");
		String QUestionHasMLine = sc.next();

		LocalDate ed = LocalDate.parse(surveyEndDate);
		createsurveybean.setId(surveyid);
		createsurveybean.setName(surveyName);
		createsurveybean.setDescrip(surveyDescription);
		createsurveybean.setStartDate(sd);
		createsurveybean.setEndDate(ed);
		createsurveybean.setQuestionsHasOneOption(question1option);
		createsurveybean.setQ1option1(Q1option1);
		createsurveybean.setQ1option2(Q1option2);
		createsurveybean.setQ1option3(Q1option3);
		createsurveybean.setQ1option4(Q1option4);
		createsurveybean.setQuestionsHasMultipleOption(QuestionHasMoption);
		createsurveybean.setQ2option1(Q2option1);
		createsurveybean.setQ2option2(Q2option2);
		createsurveybean.setQ2option3(Q2option3);
		createsurveybean.setQ2option4(Q2option4);
		createsurveybean.setQuestionsHasSingleLine(QUestionHasSLine);
		createsurveybean.setQuestionsModelDescripitive(QUestionHasMLine);
		createsurveybean.setStartDate(sd);
		createsurveybean.setEndDate(ed);

		ArrayList<SurveyDetails> surveylist = new ArrayList<SurveyDetails>();
		surveylist.add(createsurveybean);
		surveyor1.addAll(surveylist);

		if (surveylist.isEmpty()) {
			log.info(" survey creation is not Successful");
			return false;
		} else {

			log.info("survey creation is successfull \n");
		}
		return true;
	}

	@Override
	public List<SurveyDetails> UpdateSurveyDetails(SurveyDetails cb) {
		SurveyorImplementValidation inputValid = Factory.getSurveyorValidationInstance();
		try {
			for (SurveyDetails createsurveybean : surveyor1) {
				log.info("please enter the survey id to update...[0-4]");
				String surveyid = sc.next();
				while (!inputValid.IdValidation(surveyid)) {
					log.info("please enter the valid format");
					surveyid = sc.next();
				}
				if (createsurveybean.getId().equals(surveyid)) {
					count++;
					log.info("Do you want edit Survey Details or its QUestions...?");
					P: do {

						log.info("1.Edit Survey..");
						log.info("2.Edit Survey Questions and option");
						log.info("3.exit");
						String choice = sc.nextLine();
						while (!inputValid.choiceCheckValidate(choice)) {
							log.info("please enter the valid Surveyer Option");
							choice = sc.nextLine();
						}
						int surveyorCRUD = Integer.parseInt(choice);
						switch (surveyorCRUD) {
						case 1:
							log.info("..........edit Questions........");
							log.info("enter new Survey Name..");
							String surveyName = sc.next();
							createsurveybean.setName(surveyName);
							log.info("Survey Name update successfully");
							log.info(" ");
							log.info("enter new Survey description");
							String surveyDescription = sc.next();
							createsurveybean.setDescrip(surveyDescription);
							log.info("SurveyDescription updated Successfully");
							log.info(" ");
							log.info("enter the new start date....");
							String surveyStartDate1 = sc.next();
							while (!inputValid.startDateValidation(surveyStartDate1)) {
								log.info("enter valid start date");
								surveyStartDate1 = sc.next();
							}
							LocalDate sd1 = LocalDate.parse(surveyStartDate1);
							createsurveybean.setStartDate(sd1);
							log.info("start date updated successfully");
							log.info(" ");
							log.info("enter the end date.......");
							String enddate1 = sc.next();
							while (!inputValid.EndDateValidation(enddate1)) {
								log.info("enter valid End date");
								enddate1 = sc.next();
							}
							LocalDate ed1 = LocalDate.parse(enddate1);
							createsurveybean.setEndDate(ed1);
							log.info("End date updated successfully");
							log.info(" ");
							break;
						case 2:
							log.info("......Update the Survey Detailsss.....");
							log.info("enter the new Question");
							String Q1 = sc.next();
							createsurveybean.setQuestionsHasOneOption(Q1);
							log.info("enter new option 1");
							String QO1 = sc.next();
							createsurveybean.setQ1option1(QO1);
							log.info("enter new option 2");
							String QO2 = sc.next();
							createsurveybean.setQ1option2(QO2);
							log.info("enter new option 3");
							String QO3 = sc.next();
							createsurveybean.setQ1option3(QO3);
							log.info("enter new option 4");
							String QO4 = sc.next();
							createsurveybean.setQ1option4(QO4);

							log.info("*********************");
							log.info("enter the new Question ");
							String Q2 = sc.next();
							createsurveybean.setQuestionsHasMultipleOption(Q2);
							log.info("enter new option 1");
							String Q21 = sc.next();
							createsurveybean.setQ2option1(Q21);
							log.info("enter new option 2");
							String Q22 = sc.next();
							createsurveybean.setQ2option2(Q22);
							log.info("enter new option 3");
							String Q23 = sc.next();
							createsurveybean.setQ2option3(Q23);
							log.info("enter new option 4");
							String Q24 = sc.next();
							createsurveybean.setQ2option4(Q24);
							log.info("************************");
							log.info("enter the new Q3");
							String Q3 = sc.next();
							createsurveybean.setQuestionsHasSingleLine(Q3);
							log.info("********************");
							log.info("enter the new Q4");
							String Q4 = sc.next();
							createsurveybean.setQuestionsModelDescripitive(Q4);
							break;
						case 3:
							break P;
						}
					} while (true);

				}
			}
			if (count == 0) {
				throw new SurveyIdNotFoundException();
			}

		} catch (SurveyIdNotFoundException e) {
			log.error(e.exceptionMessage());

		}
		return surveyor1;
	}

	public List<SurveyDetails> getSurveyorDetails() {
		try {
			log.info("please enter the survey id to display");
			String surveyId = sc.next();
			for (SurveyDetails createsurveyBean : surveyor1) {
				if (createsurveyBean.getId().equals(surveyId)) {
					log.info(createsurveyBean);
					count++;
				}
			}
			if (count == 0) {
				throw new SurveyIdNotFoundException();
			}
		} catch (SurveyIdNotFoundException e) {
			log.error(e.exceptionMessage());
		}
		return surveyor1;
	}

	public List<SurveyDetails> deleteSurveyor() {
		log.info("please enter the survey id to display");
		String surveyId = sc.next();
		for (SurveyDetails createsurveyBean : surveyor1) {
			if (createsurveyBean.getId().equals(surveyId)) {
				count++;
				surveyor1.remove(createsurveyBean);
				log.info("survey details deleted successfully");
			}
		}
		try {
			if (count == 0) {
				throw new SurveyIdNotFoundException();
			}
		} catch (SurveyIdNotFoundException e) {
			log.error(e.exceptionMessage());
		}
		return surveyor1;

	}

	public List<SurveyDetails> getAllSurveyor() {
		SurveyorImplementValidation inputValid = Factory.getSurveyorValidationInstance();
		
			log.info("enter the valid option you want.... ?\n");
			P: do {
				log.info("1. View all Names of Surveys present.");
				log.info("2. View all details.");
				log.info("3.exit");
				String choice = sc.next();
				while (!inputValid.choiceCheckValidate(choice)) {
					log.info("please enter the valid Option");
					choice = sc.next();
				}
				int option = Integer.parseInt(choice);

				switch (option) {
				case 1:
					for (SurveyDetails survey : surveyor1) {
					log.info("Your surveys informations  are:");

					log.info("Surveyid          :" + " " + survey.getId());
					log.info("SurveyName        :" + " " + survey.getName());
					log.info("Survey Description:" + " " + survey.getDescrip());
					log.info("Survey StartDate  :" + " " + survey.getStartDate());
					log.info("survey EndDate    :" + " " + survey.getEndDate());

					log.info("**************************************");
					}
					break;
					
				case 2:
					for (SurveyDetails survey : surveyor1) {
					log.info("All details of Survey are....:");
					log.info(survey);
					}
					break;
					
				case 3:
					break P;
				}

			} while (true);
		return surveyor1;
	}

	@Override
	public boolean getRegistrationSurveyor() {
		SurveyorValidation inputValid = Factory.getSurveyorValidationInstance();
		Surveyor surveyorBean = Factory.getSurveyorBeanInstance();

		log.info("Enter the  SurveyId { It accept [1-3] characters only }");
		String id = sc.next();
		while (!inputValid.IdValidation(id)) {
			log.info("enter valid id");
			id = sc.next();
		}
		log.info("Enter your First Name { It accept [a-z,A-Z] characters only }");
		String Fname = sc.next();
		while (!inputValid.NameValidation(Fname)) {
			log.info("enter valid First name");
			Fname = sc.next();
		}

		log.info("Enter your last Name { It accept [a-zA-Z] characters only }");
		String Lname = sc.next();
		while (!inputValid.NameValidation(Lname)) {
			log.info("enter valid  Last name");
			Lname = sc.next();
		}
		log.info("Enter your password...{[a-zA-Z0-9$@] format only}");
		String password = sc.next();
		while (!inputValid.passwordValidation(password)) {
			log.info("enter valid Password");
			password = sc.next();
		}

		log.info("Enter your contactNumber...{[[7-9][0-9][9] format only}");
		String contactNo = sc.next();
		while (!inputValid.contactNoValidation(contactNo)) {
			log.info("enter valid contactNumber");
			contactNo = sc.next();
		}
		surveyorBean.setSurveyUserid(id);
		surveyorBean.setsFirstName(Fname);
		surveyorBean.setsLastName(Lname);
		surveyorBean.setsContactNumber(contactNo);
		surveyorBean.setSurveyPassword(password);

		ArrayList<Surveyor> surveyorRegList = new ArrayList<Surveyor>();
		surveyorRegList.add(surveyorBean);
		surveyor.addAll(surveyorRegList);
		if (surveyorRegList.isEmpty()) {
			log.info("surveyor details is not added");
			return false;
		} else {
			log.info("surveyor details  is added Successfuly \n");
			return true;

		}

	}

}
