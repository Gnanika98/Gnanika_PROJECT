package com.capgemini.surveyapp.validation;

public interface InputValidation {

	boolean ChoiceCheckValidate(String extractPerson);

	boolean passwordValidation(String password);

	boolean UseridValidation(String userid);

}
