package com.capgemini.surveyapp.service;

import com.capgemini.surveyapp.Bean.Surveyor;

public interface SurveyorService {

	public boolean surveyorServLogin(Surveyor surveyorInfoBean);

	public boolean surveyorServCreate();

	void surveyorServSurveyView();

	public void surveyorServSurveyUpdate();

	public void surveyorServSurveydelete();

    public boolean surveyorCreateSurvey();

	public void defaultSurveyLogin();

	public void defaultSurveyorSurveyDesc();

	public void surveyorServSurveyViewAll();

	public void surveyorServRegistration();

}
