package com.capgemini.surveyapp.service;

import com.capgemini.SurveyAPP.bean.RespondentInfoBean;
import com.capgemini.surveyapp.dao.RespondentDAO;

public interface RespondentService {

	void defaultrespondentLogin();


	public void respondentCreateDetails();

	public void getrespondentServiceLayer();

	void getrespondentViewResponses();

	void respondentServresgistration();


	void defaultrespondent();


	//void getNoOFDistriubtion();

}
