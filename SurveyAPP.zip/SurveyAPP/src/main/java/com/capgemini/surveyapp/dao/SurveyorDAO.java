package com.capgemini.surveyapp.dao;

import java.util.List;

import com.capgemini.surveyapp.Bean.SurveyDetails;
import com.capgemini.surveyapp.Bean.Surveyor;


public interface SurveyorDAO {

	public void defaultSurveyorLogin();

	public boolean surveyorLogin(Surveyor surveyor1);

	public boolean surveyorCreateSurvey();

	public List<SurveyDetails> getSurveyorDetails();

	public  List<SurveyDetails> UpdateSurveyDetails(SurveyDetails cb);

	public  List<SurveyDetails> deleteSurveyor();
	
	public boolean surveyorCreateSurveyDetails();
	
	public void defaultSurveyorSurveyDesc();

	public List<SurveyDetails> getAllSurveyor();

	public boolean getRegistrationSurveyor();


	

}
