package com.capgemini.surveyapp.Bean;

import java.util.Arrays;

public class RespondentDetails {
	private String qNo;
	private String Q1Answer1;
	private String Q1Answer3;
	private String Q1Answer4;

	public String getQ1Answer1() {
		return Q1Answer1;
	}

	public void setQ1Answer1(String q1Answer1) {
		Q1Answer1 = q1Answer1;
	}

	public String getQ1Answer3() {
		return Q1Answer3;
	}

	public void setQ1Answer3(String q1Answer3) {
		Q1Answer3 = q1Answer3;
	}

	public String getQ1Answer4() {
		return Q1Answer4;
	}

	public void setQ1Answer4(String q1Answer4) {
		Q1Answer4 = q1Answer4;
	}
	

	public String getQNo() {
		return qNo;
	}

	public void setQid(String qNo) {
		this.qNo = qNo;
	}


	private String al[];
	public String[] getAl() {
		return al;
	}

	public void setAl(String[] al) {
		this.al = al;
	}



	private String[]  Al1;

	public String[] getAl1() {
		return al;
	}

	public void setAl1(String[] al) {
		this.al = al;
	}

	@Override
	public String toString() {
		return "CreateRespondentDetailsBean [qid=" + qid + ", Q1Answer1=" + Q1Answer1 + ", Q1Answer3=" + Q1Answer3
				+ ", Q1Answer4=" + Q1Answer4 + ", al=" + Arrays.toString(al) + "]";
	}

	private String respndentid;

	public String getRespndentid() {
		return respndentid;
	}

	public void setRespndentid(String respndentid) {
		this.respndentid = respndentid;
	}
	
	
}
