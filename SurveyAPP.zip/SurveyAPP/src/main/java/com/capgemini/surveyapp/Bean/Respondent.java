package com.capgemini.surveyapp.Bean;

public class Respondent {
	private String RespondentId;
	private String RespondentPassword;
	private String Respondentname;
	private String RespondentLname;
	private String RespondentContact;

	public String getRespondentId() {
		return RespondentId;
	}

	public void setRespondentId(String respondentId) {
		RespondentId = respondentId;
	}

	public String getRespondentPassword() {
		return RespondentPassword;
	}

	public void setRespondentPassword(String respondentPassword) {
		RespondentPassword = respondentPassword;
	}

	public String getRespondentFname() {
		return RespondentFname;
	}

	public void setRespondentFname(String respondentFname) {
		RespondentFname = respondentFname;
	}

	public String getRespondentLname() {
		return RespondentLname;
	}

	public void setRespondentLname(String respondentLname) {
		RespondentLname = respondentLname;
	}

	public String getRespondentContact() {
		return RespondentContact;
	}

	public void setRespondentContact(String respondentContact) {
		RespondentContact = respondentContact;
	}

	

}
