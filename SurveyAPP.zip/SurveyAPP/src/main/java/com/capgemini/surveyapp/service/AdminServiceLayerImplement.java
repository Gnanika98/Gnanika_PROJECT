package com.capgemini.surveyapp.service;

import com.capgemini.SurveyAPP.bean.AdminInfoBean;
import com.capgemini.SurveyAPP.bean.SurveyorInfoBean;
import com.capgemini.surveyapp.dao.AdminDAO;
import com.capgemini.surveyapp.dao.AdminDAOImplement;
import com.capgemini.surveyapp.dao.SurveyorDAO;
import com.capgemini.surveyapp.dao.SurveyorDAOImplement;

public class AdminServiceLayerImplement implements AdminServiceLayer {
	public boolean AdminLogin(Admin AdminInfoBean) {
	     AdminDAO adminDAO1= new AdminDAOImplement();
		 boolean b=adminDAO1.AdminLogin(AdminInfoBean);
		 return b;
	}

	@Override
	public boolean adminService() {
		AdminDAO adminDAO1= new AdminDAOImplement();
		return adminDAO1.LogIntoRespAccount();
		
	}

	@Override
	public void defaultadminLogin() {
		AdminDAO adminDAO1= new AdminDAOImplement();
		 adminDAO1.defaultAdminLogin();
		
	}

}
