package com.capgemini.surveyapp.validation;

import java.time.LocalDate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SurveyorImplementValidation implements SurveyorValidation {
	Pattern pattn = null;
	Matcher mattn = null;

	@Override
	public boolean startDateValidation(String surveyStartDate) {
		LocalDate a=LocalDate.now();
		LocalDate ed = LocalDate.parse(surveyStartDate);
		pattn = Pattern.compile("\\d{4}-\\d{2}-\\d{2}");
		mattn = pattn.matcher(surveyStartDate);
		if (mattn.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean EndDateValidation(String surveyEndDate) {
		LocalDate a=LocalDate.now();
		LocalDate ed = LocalDate.parse(surveyEndDate);
		pattn = Pattern.compile("\\d{4}-\\d{2}-\\d{2}");
		mattn = pattn.matcher(surveyEndDate);
		if (mattn.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean IdValidation(String surveyid) {
		pattn = Pattern.compile("\\d{1,3}");
		mattn = pattn.matcher(surveyid);
		if (mattn.matches()) {
			return true;
		}
		return false;
	}

	public boolean NameValidation(String surveyName) {
		pattn = Pattern.compile("[a-zA-Z.]+");
		mattn = pattn.matcher(surveyName);
		if (mattn.matches()) {
			return true;
		}
		return false;
	}

	public boolean QuestionsIdValidation(String questionsid) {
		pattn = Pattern.compile("\\d{1,3}");
		mattn = pattn.matcher(questionsid);
		if (mattn.matches()) {
			return true;
		}
		return false;
	}

	public boolean choiceCheckValidate(String choice) {
		pattn = Pattern.compile("[1-3]");
		mattn = pattn.matcher(choice);
		if (mattn.matches()) {
			return true;
		}
		return false;
	}

	public boolean ViewValidation(String s) {
		pattn = Pattern.compile("[1-2]");
		mattn = pattn.matcher(s);
		if (mattn.matches()) {
			return true;
		}
		return false;
	}

	public boolean QuestionsFormatValidation(String question1option) {
		pattn = Pattern.compile("^[A-Za-z]*$");
		mattn = pattn.matcher(question1option);
		if (mattn.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean passwordValidation(String password) {
		pattn = Pattern.compile("[a-zA-Z0-9@$]+");
		mattn = pattn.matcher(password);
		if (mattn.matches()) {
			return true;
		}
		
		return false;
	}

	@Override
	public boolean contactNoValidation(String contactNo) {
		pattn = Pattern.compile("[7-9][0-9]{9}");
		mattn = pattn.matcher(contactNo);
		if (mattn.matches()) {
			return true;
		}
		return false;
	}


}
