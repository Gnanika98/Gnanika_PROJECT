package com.capgemini.surveyapp.dao;

import java.util.List;

import com.capgemini.surveyapp.Bean.RespondentDetails;


public interface RespondentDAO {

	void defaultRespondentLogin();

	boolean RespondentProcessing();

	public List<RespondentDetails> respondServiceLayer();

	List<RespondentDetails>respondView();

	boolean respondResgistration();

	boolean RespondentLogin();
	

}
