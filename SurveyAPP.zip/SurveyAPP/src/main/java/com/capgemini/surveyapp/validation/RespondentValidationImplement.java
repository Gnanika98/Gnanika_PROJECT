
package com.capgemini.surveyapp.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RespondentValidationImplement implements RespondentValidation {
	Pattern pattn = null;
	Matcher mattn = null;
	@Override
	public boolean answerValidation(String answer) {
		pattn = Pattern.compile("[1-4]");
		mattn = pattn.matcher(answer);
		if (mattn.matches()) {
			return true;
		}
		return false;
	}
	@Override
	public boolean singleLineQuestionValidation(String singleline) {
		pattn = Pattern.compile("^[a-zA-Z] {1,200}$");
		mattn = pattn.matcher(singleline);
		if (mattn.matches()) {
			return true;
		}
		return false;
	}
	@Override
	public boolean MultipleLineQuestionValidation(String multipleline) {
		pattn = Pattern.compile("^[a-zA-Z] {1,4000}$");
		mattn = pattn.matcher(multipleline);
		if (mattn.matches()) {
			return true;
		}
		return false;
	}
	@Override
	public boolean choiceRespValid(String responses) {
		pattn = Pattern.compile("[1-3]");
		mattn = pattn.matcher(responses);
		if (mattn.matches()) {
			return true;
		}
		return false;
	}
	@Override
	public boolean DistribValid(String s) {
		pattn = Pattern.compile("[1-2]");
		mattn = pattn.matcher(s);
		if (mattn.matches()) {
			return true;
		}
		return false;
	}
	@Override
	public boolean UseridValidation(String userid) {
		pattn = Pattern.compile("\\{1,3}");
		mattn = pattn.matcher(userid);
		if (mattn.matches()) {
			return true;
		}
		return false;
	}
}
