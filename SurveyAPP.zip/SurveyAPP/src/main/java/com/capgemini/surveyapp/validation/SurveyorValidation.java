package com.capgemini.surveyapp.validation;

public interface SurveyorValidation {
	
	boolean startDateValidation(String surveyStartDate);

	boolean EndDateValidation(String surveyStartDate);

	boolean IdValidation(String surveyid);
	
	boolean QuestionsIdValidation(String questionsid);
	
	public boolean NameValidation(String surveyName);
	
	public boolean choiceCheckValidate(String choice);

	boolean passwordValidation(String password);

	boolean contactNoValidation(String contactNo);
	
}
