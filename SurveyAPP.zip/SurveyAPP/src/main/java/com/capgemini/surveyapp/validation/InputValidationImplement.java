package com.capgemini.surveyapp.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InputValidationImplement implements InputValidation {
	Pattern pattn = null;
	Matcher mattn = null;

	@Override
	public boolean ChoiceCheckValidate(String extractPerson) {
		pattn = Pattern.compile("[1-6]");
		mattn = pattn.matcher(extractPerson);
		if (mattn.matches()) {
			return true;
		}
		return false;
	}
	
	public boolean passwordValidation(String password) {
		pattn = Pattern.compile("[a-zA-Z0-9@$]+");
		mattn = pattn.matcher(password);
		if (mattn.matches()) {
			return true;
		}
		return false;
		
	}

	@Override
	public boolean UseridValidation(String userid) {
		pattn = Pattern.compile("[a-zA-Z0-9@$]+");
		mattn = pattn.matcher(userid);
		if (mattn.matches()) {
			return true;
		}
		return false;
	}

}