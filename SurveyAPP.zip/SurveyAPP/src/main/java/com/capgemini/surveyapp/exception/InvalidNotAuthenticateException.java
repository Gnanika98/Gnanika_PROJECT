package com.capgemini.surveyapp.exception;

import org.apache.log4j.Logger;

public class InvalidNotAuthenticateException extends RuntimeException {
	String message="You will not have the permission to access this survey ......";
	public org.apache.log4j.Logger logger = Logger.getLogger(InvalidNotAuthenticateException.class);

	public String exceptionMessage() {
		return message;
	}
}
