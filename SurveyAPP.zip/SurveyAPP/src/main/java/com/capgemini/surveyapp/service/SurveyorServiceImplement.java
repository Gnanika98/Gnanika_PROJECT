package com.capgemini.surveyapp.service;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.SurveyAPP.bean.CreateSurveyDetailsBean;
import com.capgemini.SurveyAPP.bean.SurveyorInfoBean;
import com.capgemini.surveyapp.dao.SurveyorDAO;
import com.capgemini.surveyapp.dao.SurveyorDAOImplement;
import com.capgemini.surveyapp.factory.Factory;
import com.capgemini.surveyapp.validation.InputValidationImplement;
import com.capgemini.surveyapp.validation.SurveyorImplementValidation;

public class SurveyorServiceImplement implements SurveyorService  {
	static final Logger log = Logger.getLogger(SurveyorServiceImplement.class);
	Scanner sc = new Scanner(System.in);
	@Override
	public boolean surveyorServLogin(Surveyor surveyorInfoBean) {
		SurveyorDAO surveyorDAO1= new SurveyorDAOImplement();
		 boolean b=surveyorDAO1.surveyorLogin(surveyorInfoBean);
		 return b;
	}

	@Override
	public boolean surveyorServCreate() {
		SurveyorDAO surveyorDAO2= new SurveyorDAOImplement();
	    return surveyorDAO2.surveyorCreateSurvey();
		
		
	}

	@Override
	public void surveyorServSurveyView() {
		SurveyorDAO surveyorDAO3= new SurveyorDAOImplement();
		surveyorDAO3.getSurveyorDetails();
		
	}

	@Override
	public void surveyorServSurveyUpdate() {
		SurveyorDAO surveyorDAO4= new SurveyorDAOImplement();
		SurveyDetails surveybean=new SurveyDetails();
		surveyorDAO4.UpdateSurveyDetails(surveybean);
		
	}

	@Override
	public void surveyorServSurveydelete() {
		SurveyorDAO surveyorDAO= new SurveyorDAOImplement();
		surveyorDAO.deleteSurveyor();
	}

	@Override
	public boolean surveyorCreateSurvey() {
		SurveyorDAO surveyorDAO= new SurveyorDAOImplement();
		boolean b= surveyorDAO.surveyorCreateSurveyDetails();
		return b;
	}

	@Override
	public void defaultSurveyLogin() {
		SurveyorDAO surveyorDAO= new SurveyorDAOImplement();
		 surveyorDAO.defaultSurveyorLogin();
	}

	@Override
	public void defaultSurveyorSurveyDesc() {
		SurveyorDAO surveyorDAO= new SurveyorDAOImplement();
		 surveyorDAO.defaultSurveyorSurveyDesc();
		
	}

	@Override
	public void surveyorServSurveyViewAll() {
		SurveyorDAO surveyorDAO= new SurveyorDAOImplement();
		 surveyorDAO.getAllSurveyor();
		
		
	}

	@Override
	public void surveyorServRegistration() {
		SurveyorDAO surveyorDAO= new SurveyorDAOImplement();
		 surveyorDAO.getRegistrationSurveyor();
	}
	

}


