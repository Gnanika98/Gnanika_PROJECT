package com.capgemini.surveyapp.validation;

import static org.junit.Assert.assertEquals;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.surveyapp.factory.Factory;

public class TestSurveyorValidSession {
	static final Logger log = Logger.getLogger(TestSurveyorValidSession.class);
	Scanner sc = new Scanner(System.in);

	@Test
	@DisplayName("UseridValidation")
	void TestUserid() {
		SurveyorValidation iv=Factory.getSurveyorValidationInstance();
		log.info("\n\n....enter userid to verify...\n\n");
		String s=sc.next();
		assertEquals(true,iv.IdValidation(s));
	}
	
	@Test
	@DisplayName("Name Validation")
	void TestName() {
		SurveyorValidation iv=Factory.getSurveyorValidationInstance();
		log.info("\n\n....enter Name to verify...\n\n");
		String s=sc.next();
		assertEquals(true,iv.NameValidation(s));
	}
	@Test
	@DisplayName("StartDateValidation")
	void TestStartDateValidation() {
		SurveyorValidation iv=Factory.getSurveyorValidationInstance();
		log.info("\n\n....enter Name to verify...\n\n");
		String s=sc.next();
		assertEquals(true,iv.startDateValidation(s));
		
	}
	@Test
	@DisplayName("EndDateValidation")
	void TestEndDateValidation() {
		SurveyorValidation iv=Factory.getSurveyorValidationInstance();
		log.info("\n\n....enter Name to verify...\n\n");
		String s=sc.next();
		assertEquals(true,iv.EndDateValidation(s));
		
	}
	@Test
	@DisplayName("QuestionIdValidation")
	void TestQuestionValidation() {
		SurveyorValidation iv=Factory.getSurveyorValidationInstance();
		log.info("\n\n....enter Name to verify...\n\n");
		String s=sc.next();
		assertEquals(true,iv.QuestionsIdValidation(s));
		
	}
	@Test
	@DisplayName("PasswordValidation")
	void TestPasswordValidation() {
		SurveyorValidation iv=Factory.getSurveyorValidationInstance();
		log.info("\n\n....enter password to verify...\n\n");
		String s=sc.next();
		assertEquals(true,iv.passwordValidation(s));
	}
		
	@Test
	@DisplayName("ChoiceCheckValidation")
	void TestChoiceCheckValidation() {
		SurveyorValidation iv=Factory.getSurveyorValidationInstance();
		log.info("\n\n....enter choice to verify...\n\n");
		String s=sc.next();
		assertEquals(true,iv.passwordValidation(s));
	}
	@Test
	@DisplayName("ContactValidationValidation")
	void TestContactValidation() {
		SurveyorValidation iv=Factory.getSurveyorValidationInstance();
		log.info("\n\n....enter contact to verify...\n\n");
		String s=sc.next();
		assertEquals(true,iv.contactNoValidation(s));
	}
			
	
}
