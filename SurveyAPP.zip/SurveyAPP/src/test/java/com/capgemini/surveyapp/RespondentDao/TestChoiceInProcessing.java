package com.capgemini.surveyapp.RespondentDao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.surveyapp.dao.RespondentDAO;
import com.capgemini.surveyapp.factory.Factory;

public class TestChoiceInProcessing {
	static final Logger log = Logger.getLogger(TestChoiceInProcessing.class);
	Scanner sc = new Scanner(System.in);

	@Test
	@DisplayName("Responses")
	void TestChoice() {
		log.info("\n\n--------------Give responses for Survey Questions-------------\n\n");
		RespondentDAO respondentDao = Factory.getRespondentDAOInstance();
		assertNull(respondentDao.respondServiceLayer());
	}

	@Test
	@DisplayName("Responses1")
	void TestChoice1() {
		log.info("\n\n--------------Give responses for Survey Questions-------------\n\n");
		RespondentDAO respondentDao = Factory.getRespondentDAOInstance();
		assertNotNull(respondentDao.respondServiceLayer());
	}

}
