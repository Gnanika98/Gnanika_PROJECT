package com.capgemini.surveyapp.Surveydao;

import static org.junit.Assert.assertEquals;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.surveyapp.dao.SurveyorDAO;
import com.capgemini.surveyapp.factory.Factory;

public class TestAddSurvey {
	static final Logger log = Logger.getLogger(TestAddSurvey.class);
	Scanner sc = new Scanner(System.in);

	@Test
	@DisplayName("Add Survey")
	void TestAddSurv() {
		log.info("\n\n--------------Add the Survey details-------------\n\n");
		SurveyorDAO surveyorDao = Factory.getSurveyorDAOInstance();
		assertEquals(true, surveyorDao.surveyorCreateSurvey());
	}

	@Test
	@DisplayName("Add Survey1")
	void TestAddSurv1() {
		log.info("\n\n--------------Add the Survey details-------------\n\n");
		SurveyorDAO surveyorDao = Factory.getSurveyorDAOInstance();
		assertEquals(false, surveyorDao.surveyorCreateSurvey());
	}
}
