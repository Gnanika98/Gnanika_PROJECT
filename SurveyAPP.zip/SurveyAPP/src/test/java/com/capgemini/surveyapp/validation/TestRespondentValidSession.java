package com.capgemini.surveyapp.validation;

import static org.junit.Assert.assertEquals;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.surveyapp.factory.Factory;

public class TestRespondentValidSession {
	static final Logger log = Logger.getLogger(TestInputValidSession.class);
	Scanner sc = new Scanner(System.in);
	@Test
	@DisplayName("ChoiceRespondentValidation")
	void TestPasswordValidation() {
		RespondentValidation iv=Factory.getRespondentValidationService();
		log.info("\n\n....enter choice to verify...\n\n");
		String s=sc.next();
		assertEquals(true,iv.choiceRespValid(s));
	}
	
	@Test
	@DisplayName("User id Validation")
	void TestUseridValidation() {
		RespondentValidation iv=Factory.getRespondentValidationService();
		log.info("\n\n....enter userid to verify...\n\n");
		String s=sc.next();
		assertEquals(true,iv.UseridValidation(s));
	}
}
