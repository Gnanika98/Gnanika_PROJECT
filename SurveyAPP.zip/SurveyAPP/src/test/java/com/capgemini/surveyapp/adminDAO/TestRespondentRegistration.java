package com.capgemini.surveyapp.adminDAO;

import static org.junit.Assert.assertEquals;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.surveyapp.dao.RespondentDAO;
import com.capgemini.surveyapp.dao.SurveyorDAO;
import com.capgemini.surveyapp.factory.Factory;

public class TestRespondentRegistration {
	static final Logger log = Logger.getLogger(TestRespondentRegistration.class);
	Scanner sc = new Scanner(System.in);

	@Test
	@DisplayName("Registration responder")
	void TestRegsResp() {
		log.info("\n\n--------------Responder Registration details------------\n\n");
		RespondentDAO rdao=Factory.getRespondentDAOInstance();
		assertEquals(true, rdao.respondResgistration());
	}
	
	@Test
	@DisplayName("Registration responder1")
	void TestRegsResp1() {
		log.info("\n\n--------------Responder Registration details------------\n\n");
		RespondentDAO rdao=Factory.getRespondentDAOInstance();
		assertEquals(false, rdao.respondResgistration());
	}
	
}
