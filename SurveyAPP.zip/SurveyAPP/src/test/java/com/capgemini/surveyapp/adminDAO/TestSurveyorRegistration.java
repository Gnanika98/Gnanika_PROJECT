package com.capgemini.surveyapp.adminDAO;

import static org.junit.Assert.assertEquals;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.surveyapp.Surveydao.TestAddSurvey;
import com.capgemini.surveyapp.dao.SurveyorDAO;
import com.capgemini.surveyapp.factory.Factory;

public class TestSurveyorRegistration {
	static final Logger log = Logger.getLogger(TestSurveyorRegistration.class);
	Scanner sc = new Scanner(System.in);

	@Test
	@DisplayName("Registration Survey")
	void TestRegsSurv() {
		log.info("\n\n--------------Surveyor Registration details------------\n\n");
		SurveyorDAO surveyorDao = Factory.getSurveyorDAOInstance();
		assertEquals(true, surveyorDao.getRegistrationSurveyor());
	}
	

	@Test
	@DisplayName("Registration Survey1")
	void TestRegsSurv1() {
		log.info("\n\n--------------Surveyor Registration details------------\n\n");
		SurveyorDAO surveyorDao = Factory.getSurveyorDAOInstance();
		assertEquals(false, surveyorDao.getRegistrationSurveyor());
	}

}
