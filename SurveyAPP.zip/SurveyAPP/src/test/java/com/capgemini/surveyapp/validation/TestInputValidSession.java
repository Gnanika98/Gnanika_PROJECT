package com.capgemini.surveyapp.validation;

import static org.junit.Assert.assertEquals;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.surveyapp.adminDAO.TestRespondentRegistration;
import com.capgemini.surveyapp.dao.RespondentDAO;
import com.capgemini.surveyapp.factory.Factory;

public class TestInputValidSession {
	static final Logger log = Logger.getLogger(TestInputValidSession.class);
	Scanner sc = new Scanner(System.in);

	@Test
	@DisplayName("UseridValidation")
	void TestUserid() {
		InputValidation iv=Factory.getInputValidationInstance();
		log.info("\n\n....enter userid to verify...\n\n");
		String s=sc.next();
		assertEquals(true,iv.UseridValidation(s));
	}
	
	@Test
	@DisplayName("ChoiceCheckValidation")
	void TestChoiceCheck() {
		InputValidation iv=Factory.getInputValidationInstance();
		log.info("\n\n....enter choice to verify...\n\n");
		String s=sc.next();
		assertEquals(true,iv.ChoiceCheckValidate(s));
		
	}
	
	@Test
	@DisplayName("PasswordValidation")
	void TestPasswordValidation() {
		log.info("\n\n--------------Password Validation------------\n\n");
		InputValidation iv=Factory.getInputValidationInstance();
		log.info("enter password to verify");
		String s=sc.next();
		assertEquals(true,iv.passwordValidation(s));
	}
}
