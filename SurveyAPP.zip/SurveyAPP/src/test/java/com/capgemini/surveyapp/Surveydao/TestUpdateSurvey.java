package com.capgemini.surveyapp.Surveydao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.SurveyAPP.bean.CreateSurveyDetailsBean;
import com.capgemini.surveyapp.dao.SurveyorDAO;
import com.capgemini.surveyapp.factory.Factory;

public class TestUpdateSurvey {
	static final Logger log = Logger.getLogger(TestUpdateSurvey.class);
	Scanner sc = new Scanner(System.in);

	@Test
	@DisplayName("Update Survey")
	void testUpdateSurvey() {
	    log.info("\n\n--------------Update the Survey details-------------\n\n");
	    SurveyorDAO surveyorDao=Factory.getSurveyorDAOInstance();
	    SurveyDetails cb= Factory.getcreateSurveyInstance();
	    assertNull(surveyorDao.UpdateSurveyDetails(cb));
	    
	}   
	@Test
	@DisplayName("Update Survey1")
	void testUpdateSurv1() {
	    log.info("\n\n--------------Update the Survey details-------------\n\n");
	    SurveyorDAO surveyorDao=Factory.getSurveyorDAOInstance();
	    SurveyDetails cb= Factory.getcreateSurveyInstance();
	    assertNotNull(surveyorDao.UpdateSurveyDetails(cb));
	    
	}   
}
