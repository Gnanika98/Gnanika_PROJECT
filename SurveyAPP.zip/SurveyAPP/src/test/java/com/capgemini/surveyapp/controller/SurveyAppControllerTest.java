package com.capgemini.surveyapp.controller;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.SurveyAPP.bean.AdminInfoBean;
import com.capgemini.SurveyAPP.bean.RespondentInfoBean;
import com.capgemini.SurveyAPP.bean.SurveyorInfoBean;
import com.capgemini.surveyapp.factory.Factory;
import com.capgemini.surveyapp.service.SurveyorService;

class SurveyAppControllerTest {
	static final Logger logg = Logger.getLogger(Controller.class);
	Scanner scann = new Scanner(System.in);

	@Test
	@DisplayName("Surveyor Login")
	void testSurveyorLogin() {
		logg.info("----------------Test cases for Surveyor Login----------");
		Surveyor surveyorservice = Factory.getSurveyorBeanInstance();
		surveyorservice.setsUserid("surveyor");
		surveyorservice.setsPassword("12345678");

		logg.info("\n\n----------------Please enter the Surveyor Login-------------------\n\n");
		logg.info("\n\n Surveyor Userid: ");
		String Surveyid = scann.next();
		assertEquals(Surveyid, surveyorservice.getsUserid());
		logg.info("\n\n Surveyor Password: ");
		String SurveyPass = scann.next();

		assertEquals(SurveyPass, surveyorservice.getsPassword());

	}

	@Test
	@DisplayName("Respondent Login")
	void testRespondentLogin() {
		logg.info("----------------Test cases for Respondent Login----------");
		Respondent respondentservice = Factory.getRespondentBeanInstance();
		respondentservice.setRespondentId("respondent");
		respondentservice.setRespondentPassword("123");

		logg.info("\n\n----------------Please enter the Respondent Login-------------------\n\n");
		logg.info("\n\n Respondent Userid: ");
		String respondentid = scann.next();
		assertEquals(respondentid, respondentservice.getRespondentId());
		logg.info("\n\n Respondent Password: ");
		String SurveyPass = scann.next();

		assertEquals(SurveyPass, respondentservice.getRespondentPassword());
	}

	@Test
	@DisplayName("Admin Login")
	void testadminLogin() {
		logg.info("----------------Test cases for Admin Login----------");
		Admin adminService = Factory.getAdminBeanInstance();
		adminService.setAdminusername("admin");
		adminService.setAdminpassword("12345");

		logg.info("\n\n----------------Please enter the Admin Login-------------------\n\n");
		logg.info("\n\n Admin Userid: ");
		String adminid = scann.next();
		assertEquals(adminid, adminService.getAdminusername());
		logg.info("\n\n Admin Password: ");
		String adminPass = scann.next();

		assertEquals(adminPass, adminService.getAdminpassword());
	}

}
