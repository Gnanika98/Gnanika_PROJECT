package com.capgemini.surveyapp.Surveydao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.SurveyAPP.bean.CreateSurveyDetailsBean;
import com.capgemini.surveyapp.dao.SurveyorDAO;
import com.capgemini.surveyapp.factory.Factory;

public class TestGetAllSurvey {
	static final Logger log = Logger.getLogger(TestGetAllSurvey.class);
	Scanner sc = new Scanner(System.in);

	@Test
	@DisplayName("ViewAll Survey")
	void testViewSurv() {
		log.info("\n\n--------------ViewAll the Survey details-------------\n\n");
		SurveyorDAO surveyorDao = Factory.getSurveyorDAOInstance();
		assertNull( surveyorDao.getAllSurveyor());
	}

	@Test
	@DisplayName("ViewAll Survey1")
	void testViewAllSurv1() {
		log.info("\n\n--------------ViewAll the Survey details-------------\n\n");
		SurveyorDAO surveyorDao = Factory.getSurveyorDAOInstance();
		assertNotNull( surveyorDao.getAllSurveyor());
	}
}
