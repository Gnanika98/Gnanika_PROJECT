package com.capgemini.surveyapp.Surveydao;

import static org.junit.Assert.assertEquals;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.surveyapp.dao.SurveyorDAO;
import com.capgemini.surveyapp.factory.Factory;

public class TestSurveyorDAO {
	static final Logger log = Logger.getLogger(TestSurveyorDAO.class);
	Scanner sc = new Scanner(System.in);

	@Test
	@DisplayName("Add Survey")
	void TestAddSurv() {
		log.info("\n\n--------------Add the Survey details-------------\n\n");
		SurveyorDAO surveyorDao = Factory.getSurveyorDAOInstance();
		assertEquals(true, surveyorDao.surveyorCreateSurvey());
	}

}
